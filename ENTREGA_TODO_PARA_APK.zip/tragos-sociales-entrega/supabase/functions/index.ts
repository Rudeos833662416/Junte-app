// Este archivo se ejecuta en Supabase Edge Functions (Deno), no en el bundle Expo.
// @ts-nocheck
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SERVICE_ROLE_KEY") ?? "";
const supabase = createClient(supabaseUrl, serviceRoleKey);

const reactionActions = [
  { action: "REACTION_BEER", title: "🍺" },
  { action: "REACTION_FIRE", title: "🔥" },
  { action: "REACTION_CHEERS", title: "🍻" },
  { action: "REACTION_HEART", title: "❤️" },
];
const friendRequestActions = [
  { action: "ACCEPT_FRIEND", title: "Aceptar" },
  { action: "REJECT_FRIEND", title: "Rechazar" },
];
const brindarActions = [
  { action: "BRINDAR_HEALTH", title: "Salud 🍻" },
  { action: "BRINDAR_ON_WAY", title: "Voy en camino 🚗" },
];

Deno.serve(async (request) => {
  if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });
  if (!serviceRoleKey) return new Response("Missing Supabase service role configuration", { status: 500 });

  try {
    const payload = await request.json();
    const activity = payload.record ?? payload.new ?? payload;
    const activityType = activity.type ?? (activity.sender_id && activity.body ? "direct_message" : undefined);
    const recipientId = activity.recipient_id as string | undefined;
    if (!recipientId || !["check_in", "check_out", "friend_request", "reaction_story", "direct_message"].includes(activityType)) {
      return Response.json({ skipped: true });
    }

    const [{ data: tokens }, { data: actor }] = await Promise.all([
      supabase.from("push_tokens").select("expo_push_token").eq("user_id", recipientId),
      supabase.from("profiles").select("name").eq("id", activity.actor_id ?? activity.sender_id).maybeSingle(),
    ]);
    const isFriendRequest = activityType === "friend_request";
    const isStoryReaction = activityType === "reaction_story";
    const isDirectMessage = activityType === "direct_message";
    const isCheckIn = activityType === "check_in";
    const messages = (tokens ?? []).map((token) => ({
      to: token.expo_push_token,
      sound: "default",
      channelId: "friend-activity",
      priority: "high",
      title: actor?.name ?? "Un usuario",
      body: isDirectMessage ? (activity.body ?? activity.message ?? "Te envió un mensaje") : isFriendRequest ? "Te envió una solicitud de amistad" : isStoryReaction ? `Reaccionó a tu Estado ${activity.reaction_emoji ?? "💬"}` : isCheckIn ? "Está tomando algo" : "Terminó su visita. Toca para reaccionar.",
      categoryId: isDirectMessage ? "CHAT_MESSAGE" : isFriendRequest ? "FRIEND_REQUEST" : isCheckIn ? "BRINDAR_ACTIVITY" : "FRIEND_ACTIVITY",
      data: { activityId: String(activity.id ?? ""), friendshipId: activity.friendship_id ? String(activity.friendship_id) : undefined, senderId: String(activity.actor_id ?? activity.sender_id ?? ""), screen: isDirectMessage ? "chat" : "activity" },
      _actions: isFriendRequest ? friendRequestActions : isCheckIn ? brindarActions : reactionActions,
    }));

    if (messages.length === 0) return Response.json({ sent: 0 });
    const response = await fetch("https://exp.host/--/api/v2/push/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(messages),
    });
    return Response.json({ sent: messages.length, expo: await response.json() });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Unexpected error" }, { status: 400 });
  }
});
